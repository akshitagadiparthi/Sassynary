# Sassynary Security Fixes — Migration Guide

## Overview

This package contains fixed versions of your files and new files needed to secure your Sassynary website. Below is a step-by-step guide to deploy every fix.

---

## Step 1: Move Gemini API Key Server-Side (CRITICAL)

**Problem:** Your Gemini API key was exposed in the browser via `VITE_GEMINI_API_KEY`.

**Files to update:**

1. **Copy `api/gemini.ts`** into your project root (at the same level as `package.json`).
   - Vercel automatically deploys files in the `api/` folder as serverless functions.

2. **Replace `services/geminiService.ts`** with the fixed version.
   - The new version calls `/api/gemini` instead of using the API key directly.

3. **Remove** `VITE_GEMINI_API_KEY` from your `.env` file and Vercel environment variables.

4. **Add** `GEMINI_API_KEY` (no VITE_ prefix!) in Vercel:
   - Go to: Vercel Dashboard → Your Project → Settings → Environment Variables
   - Name: `GEMINI_API_KEY`
   - Value: your actual Gemini API key
   - Scope: Production (and Preview if needed)

5. **Remove** `@google/genai` from your import map in `index.html` — it's no longer used in the browser.

6. **Add** `@vercel/node` to your devDependencies:
   ```
   npm install --save-dev @vercel/node
   ```

---

## Step 2: Deploy Firebase Security Rules (CRITICAL)

**Problem:** Your Firestore and Storage likely have wide-open rules.

1. **Firestore Rules:**
   - Go to: https://console.firebase.google.com → Project sassynary-35159
   - Click: Firestore Database → Rules tab
   - Replace everything with the content of `firebase-rules/firestore.rules`
   - Click: Publish

2. **Storage Rules:**
   - Go to: Firebase Console → Storage → Rules tab
   - Replace everything with the content of `firebase-rules/storage.rules`
   - Click: Publish

3. **Test after deploying** — try submitting a review, placing an order, and saving an address to make sure the rules aren't blocking legitimate operations.

---

## Step 3: Remove Auth Simulation Backdoor (CRITICAL)

**Problem:** Anyone could fake a login session via localStorage.

1. **Replace `contexts/AuthContext.tsx`** with the fixed version.
2. **Test:** Make sure login, register, and logout still work. If Firebase Auth is properly configured, everything should work exactly as before — the only difference is that fake/simulated sessions are no longer possible.

---

## Step 4: Add Security Headers (HIGH)

**Problem:** Your site had no security headers — vulnerable to clickjacking, MIME sniffing, etc.

1. **Replace `vercel.json`** with the fixed version.
2. After deploying, verify headers at: https://securityheaders.com/?q=sassynary.com

---

## Step 5: Fix File Upload Validation (CRITICAL)

**Problem:** Custom order form accepted any file type/size.

1. **Replace `components/CustomOrderForm.tsx`** with the fixed version.
2. This adds client-side validation (type + size), but the real enforcement is in the Storage Rules from Step 2.

---

## Step 6: Fix Order ID Generation (HIGH)

**Problem:** Order IDs used `Math.random()` which is predictable.

1. **Replace `components/CheckoutView.tsx`** with the fixed version.
2. This also adds input validation for phone numbers and pincodes.

---

## Step 7: Clean Up firebase.ts (MEDIUM)

1. **Replace `services/firebase.ts`** with the fixed version.
2. This removes production console.log leaking internal state.

---

## Step 8: Cloudflare Configuration (Recommended)

Since you're already using Cloudflare, enable these features in your Cloudflare dashboard:

1. **Bot Fight Mode:** Security → Bots → Enable Bot Fight Mode
2. **Rate Limiting:** Security → WAF → Rate Limiting Rules
   - Create a rule: If URL path contains `/api/gemini`, rate limit to 20 requests per minute per IP
   - Create a rule: If request method is POST, rate limit to 30 requests per minute per IP
3. **Browser Integrity Check:** Security → Settings → Enable Browser Integrity Check
4. **HTTPS Always:** SSL/TLS → Edge Certificates → Always Use HTTPS → ON

---

## Step 9: Future Improvements (When Ready)

These aren't urgent but will further improve your security posture:

- **Bundle dependencies with Vite** instead of loading from CDN import maps. You already have Vite configured — run `npm run build` and deploy the built output.
- **Remove Tailwind CDN** from `index.html` and use the compiled CSS from your Vite build.
- **Add Firebase App Check** to prevent automated abuse of your Firebase resources.
- **Add email verification** — require users to verify their email before placing orders.
- **Server-side price verification** — when you add real payment processing, always recalculate totals server-side.

---

## File Summary

| File | Action | Priority |
|------|--------|----------|
| `api/gemini.ts` | NEW — Add to project root | P0 |
| `services/geminiService.ts` | REPLACE | P0 |
| `contexts/AuthContext.tsx` | REPLACE | P0 |
| `firebase-rules/firestore.rules` | NEW — Deploy to Firebase Console | P0 |
| `firebase-rules/storage.rules` | NEW — Deploy to Firebase Console | P0 |
| `components/CustomOrderForm.tsx` | REPLACE | P0 |
| `vercel.json` | REPLACE | P1 |
| `components/CheckoutView.tsx` | REPLACE | P1 |
| `services/firebase.ts` | REPLACE | P2 |
| `.env.example` | NEW — Reference for env vars | Info |
